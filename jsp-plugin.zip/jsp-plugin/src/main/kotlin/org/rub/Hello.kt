package org.rub

import org.rub.jsp.JspSetting
import org.rub.jsp.Migration
import org.slf4j.LoggerFactory
import java.nio.file.Files
import java.nio.file.Paths

val actionMap = mutableMapOf(
  "/C01HRO/RP_C01HRO_211BL" to "C01HROForm",
  "/C01HRO/RP_C01HRO_213BL" to null,


)


val log = LoggerFactory.getLogger("Hello.kt")

fun main() {

  val inputPath = Paths.get("D:\\dhc\\volunteer-master\\volunteer\\web\\WEB-INF\\jsp")
  val outputPath = Paths.get("D:\\temp\\jsp\\output")
  val walk = Files.walk(inputPath)
  walk.filter(Files::isRegularFile)
//    .filter{
//      it.fileName.endsWith("tanki-common.jsp")
//    }
    .forEach {
      val jspSetting = JspSetting(log)
      jspSetting.actionMap = actionMap
      jspSetting.charset = charset("shift-jis")
      jspSetting.fileAbsPath = it.toString()
      val migration = Migration(jspSetting)


      try {
        migration.migrate(
          Files.newBufferedReader(
            it, charset("shift-jis")
          )
        )
      }catch (e:Exception){
       try {


        migration.migrate(
          Files.newBufferedReader(
            it, charset("utf-8")
          )
        )
       }catch (EE:Exception){
         println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"+it)
       }
      }



      val outFilePath = outputPath.resolve(it.toString().replace("\\dhc\\volunteer-master\\volunteer\\web\\WEB-INF",""))
      if (!outFilePath.parent.toFile().exists()) {
          Files.createDirectories(outFilePath.parent)
      }

      migration.save(outFilePath)
      log.info("file:{} is converted!", outFilePath.toString())
    }
}
