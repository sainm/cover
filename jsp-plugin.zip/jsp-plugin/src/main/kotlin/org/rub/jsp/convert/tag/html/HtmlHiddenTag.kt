package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlHiddenTag(tag: Tag) : HtmlBaseTag(tag) {

  init {
    logId = "jp-009-01"
  }

  override fun migration(): String {

    val sb = StringBuilder()
    val attrs = getAttrs()
    if (attrs.get("value") != null) return migrationFormOuter()
    val indexed: Boolean = attrs.getValue("indexed") != null
    sb.append("<form:hidden ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "path"))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "indexed", "name" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  override fun migrationFormOuter(): String {

    val sb = StringBuilder()
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null
    val value: Boolean = attrs.getValue("value") != null
    sb.append("<input type=\"hidden\" ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "name"))
        "value" -> {
          if (value) sb.append(getAttribute(it))
          else
            sb.append(
              getAttribute(
                "value", it.value.replace(" ", "").replace("<%=([^# ]+?)%>".toRegex(), "\\\${$1}")
              )
            )
        }
        "indexed", "name" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

}
