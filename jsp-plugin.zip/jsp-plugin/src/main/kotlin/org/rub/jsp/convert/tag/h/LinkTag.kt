package org.rub.jsp.convert.tag.h


import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag


//<link type="text/css" href="../css/common.css" rel="stylesheet">

//${pageContext.request.contextPath}/resources/app
class LinkTag(tag: Tag) : BaseTag(tag) {

  override fun migration(): String {
    val sb = StringBuilder()
    val attrs = getAttrs()
    sb.append("<link ")
    attrs.forEach {
      when (it.key) {
        "href" -> sb.append(getAttribute(it.key, convertPath(it.value)))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append("/>")
    return sb.toString()
  }

  private fun convertPath(path: String): String {
    val prefix = path.substring(0, path.indexOf("/"))
    return if (prefix == ".." ||
      prefix == "<%= request.getContextPath() %>" ||
      prefix == "<%=request.getContextPath()%>" ||
      prefix == "<%=request.getContextPath() %>"
    ) {
      "\${pageContext.request.contextPath}/" + path.replace("../","")
    } else {
      "\${pageContext.request.contextPath}/$path"
    }
  }
}
