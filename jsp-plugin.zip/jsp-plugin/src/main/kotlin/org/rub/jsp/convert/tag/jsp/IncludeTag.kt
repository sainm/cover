package org.rub.jsp.convert.tag.jsp



import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class IncludeTag(tag: Tag) : BaseTag(tag) {
  override fun migration(): String {

    if (tag is EndTag) return "</jsp:include>"

    val attrs = getAttrs()
    val sb = StringBuilder()
    sb.append("<jsp:include ")
    attrs.forEach {
      when (it.key) {
        "page" -> sb.append(getAttribute(it.key, "..${it.value}"))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }
}
