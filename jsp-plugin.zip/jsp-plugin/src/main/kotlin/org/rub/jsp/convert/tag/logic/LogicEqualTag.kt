package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class LogicEqualTag(tag: Tag) : LogicBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return "</r:equal>"
    val sb = StringBuilder()
    val attrs = getAttrs()
    sb.append("<r:equal ")
    attrs.forEach {
      sb.append(getAttribute(it))
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  init {
    logId = "jp-025-01"
  }
}
