package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlHtmlTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {
    return when (tag) {
      is EndTag -> "</html>"
      else -> "<html>"
    }

  }

  init {
    logId = "jp-010-01"
  }
}
