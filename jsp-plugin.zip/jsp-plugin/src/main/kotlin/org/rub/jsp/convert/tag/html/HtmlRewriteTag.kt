package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlRewriteTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {


    val attrs = getAttrs()
    val url = attrs.getValue("action")
    val sb = StringBuilder()
    sb.append("<c:url ")
    sb.append(getAttribute("value", url))
    sb.append("/>")

    return sb.toString()
  }

  init {
    logId = "jp-018-01"
  }
}
