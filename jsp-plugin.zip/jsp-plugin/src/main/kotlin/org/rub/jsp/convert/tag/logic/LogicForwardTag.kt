package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.Tag


class LogicForwardTag(tag: Tag) : LogicBaseTag(tag) {

  init {
    logId = "jp-001-01"
  }
}
