package org.rub.jsp


import net.htmlparser.jericho.Tag
import java.nio.file.Paths

class TagUtil(val setting: JspSetting?) {


  fun getTag(tag: Tag): BaseTag {
    val tagClass = getClassName(tag.name.replace(":", ".")) ?: return BaseTag(tag)
    val clazz = Class.forName(tagClass)
    val c = clazz.getDeclaredConstructor(Tag::class.java)
    c.isAccessible = true
    return c.newInstance(tag) as BaseTag
  }

  private fun getClassName(name: String): String? {

    val value = setting?.properties?.getProperty(name, null) ?: return null

    val v = value.split(",")
    if (v[1] != "0") return null

    return v[0]
  }


}

class ActionPath {
  var prePath: String? = null
  var subPath: String? = null
  var fullPath: String? = null
}

fun adjustActionPath(path: String?, fileAbsPath: String?): ActionPath? {
  if (path == null) return null
  var path = path
  val file = Paths.get(fileAbsPath).toFile()
  var prePath = ""
  var mainPath = ""
  if (path.contains("/")) {
    val paths = path.split("/").toTypedArray()
    if (paths.size > 2) {
      prePath = paths[1]
      mainPath = paths[2]
    } else {
      if (!"WEB-INF".equals(file.parentFile.name, ignoreCase = true)) {
        prePath = "/" + Paths.get(file.absolutePath).parent.fileName.toString()
      }
      mainPath = path
      path = prePath + mainPath
    }
    val actionPath: ActionPath =
      ActionPath()
    actionPath.prePath = prePath
    actionPath.subPath = mainPath
    actionPath.fullPath = path
    return actionPath
  }
  return null
}
