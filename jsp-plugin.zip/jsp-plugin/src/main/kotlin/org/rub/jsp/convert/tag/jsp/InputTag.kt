package org.rub.jsp.convert.tag.jsp


import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class InputTag(tag: Tag) : BaseTag(tag) {

  override fun migration(): String {
    val attrs = getAttrs()
    val type = attrs.getValue("type")
    if (type != "button") {
      return tag.toString()
    }

    val click = attrs.get("onclick")
    val preLoad = tag.getSource().parseText.substring(click.begin, tag.getElement().end)


    return tag.toString()
  }
}
