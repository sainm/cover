package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class LogicPresentTag(tag: Tag) : LogicBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return "</c:if>"
    val sb = StringBuilder()
    val attrs = getAttrs()
    sb.append("<c:if ")
    val property = attrs["property"]?.value
    val name = attrs["name"].value
    sb.append(getAttribute("test", getEl(name, property)))
    sb.append(appendEnd())
    return sb.toString()
  }

  private fun getEl(name: String, property: String?): String {
    val start = "\${"
    val end = "}"
    val context = getContext(name, property)
    val exp = "$context != null"
    return start + exp + end
  }

  init {
    logId = "jp-036-01"
  }
}
