package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlSubmitTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {

    val sb = StringBuilder()

    sb.append("<input type=\"submit\" ")

    getAttrs().forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))

        "property" -> sb.append(getAttribute("name", it.value))
        "disabled" -> sb.append(getDisabledAttr(it))
        "altkey", "bundle", "indexed" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append("/>")
    return sb.toString()
  }

  init {
    logId = "jp-021-01"
  }
}
