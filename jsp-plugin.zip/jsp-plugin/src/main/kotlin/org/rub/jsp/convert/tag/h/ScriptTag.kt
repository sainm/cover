package org.rub.jsp.convert.tag.h



import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Source
import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag
import org.rub.jsp.TagUtil

class ScriptTag(tag: Tag) : BaseTag(tag) {

  override fun migration(): String {
    if (tag is EndTag) return "</script>"
    val sb = StringBuilder()
    val attrs = getAttrs()
    sb.append("<script ")
    attrs.forEach {
      when (it.key) {
        "src" -> sb.append(getAttribute(it.key, convertPath(it.value)))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  private fun convertPath(path: String): String {
    val prefix = path.substring(0, path.indexOf("/"))
    return if (prefix == ".." ||
      prefix == "<%= request.getContextPath() %>" ||
      prefix == "<%=request.getContextPath()%>" ||
      prefix == "<%=request.getContextPath() %>"
    ) {
      "\${pageContext.request.contextPath}" + path.removePrefix(prefix).replace("/javascript/", "/js/").replace("../","")
    } else {
      "\${pageContext.request.contextPath}/$path".replace("/javascript/", "/js/")
    }
  }

  override fun innerConvert(): String {

    val builder = StringBuilder()
    var position = 0

    val src = Source(tag.getElement().content)
    val text = src.toString()
    val util = TagUtil(setting)
    src.getAllTags().forEach {
      if (it.begin >= position) {
        println("1#begin:${it.begin} ,position:${position}")
        builder.append(text.substring(position, it.begin))
        val tag = util.getTag(it)
        position = it.end
        println("2#begin:${it.begin} ,position:${position}")
        println()
        builder.append(tag.execute())
      } else {
        println()
      }
    }
    builder.append(src.substring(position))
    return super.innerConvert()
  }
}
