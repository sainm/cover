package org.rub.jsp.convert.tag.html




import net.htmlparser.jericho.Attribute
import net.htmlparser.jericho.Attributes
import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

open class HtmlBaseTag(tag: Tag) : BaseTag(tag) {

  override fun migration(): String {
    return tag.toString()
  }

  open fun migrationFormOuter(): String {
    return migration()
  }

  override fun execute(): String {
    return if (formFlg) migration() else migrationFormOuter()
  }

  open fun getIndexForAttr(indexed: Boolean, attribute: Attribute, attrs: Attributes): String {
    return getIndexForAttr(indexed, attribute, attrs, "path")
  }

  open fun getIndexForAttr(indexed: Boolean, attribute: Attribute, attrs: Attributes, key: String): String {
    if (!indexed) return getAttribute(key, getPrefix(attrs.getValue("name") ?: "") + attribute.value)

    return getAttribute(key, getPrefix(attrs.getValue("name"), "\${loopStatus.index}") + attribute.value)
  }

  open fun getPrefix(name: String, index: String): String {
    if (name.isEmpty()) return ""
    if (formName == name) return ""
    return "$name[$index]."
  }

  open fun getElForNameProperty(attrs: Attributes): String {
    if (attrs.getValue("name").isNullOrEmpty()) return ""
    val el = StringBuilder()
    el.append("\${")
    el.append(joinToString(attrs.getValue("name") ?: "", attrs.getValue("property") ?: ""))
    el.append("}")
    return el.toString()
  }

  init {
    logId = "jp-001-01"
  }
}
