package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Attributes
import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlRadioTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {

    if (tag is EndTag) return ""
    val sb = StringBuilder()
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null
    val value: Boolean = attrs.getValue("value") != null
    if (value) {
      sb.append("<input type=\"radio\" ")
      attrs.forEach {
        when (it.key.lowercase()) {
          "style" -> sb.append(getAttribute("style", it.value))
          "styleid" -> sb.append(getAttribute("id", it.value))
          "styleclass" -> sb.append(getAttribute("class", it.value))

          "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "name"))
          "disabled" -> sb.append(getDisabledAttr(it))
          "value" -> {
            sb.append(getAttribute(it))
            sb.append("<c:if test=\"\${${getCheckedEl(attrs)}}\">checked=\"checked\"</c:if> ")
          }
          "name", "indexed", "idname" -> ""
          else ->
            sb.append(getAttribute(it))
        }
      }
    } else {
      sb.append("<form:radiobutton ")
      attrs.forEach {
        when (it.key.lowercase()) {
          "styleid" -> sb.append(getAttribute("id", it.value))
          "styleclass" -> sb.append(getAttribute("cssClass", it.value))
          "property" -> sb.append(getIndexForAttr(indexed, it, attrs))
          "name", "indexed", "idname" -> ""
          else ->
            sb.append(getAttribute(it))
        }
      }
    }
    sb.append("/>")

    return sb.toString()
  }

  override fun migrationFormOuter(): String {

    if (tag is EndTag) return ""
    val sb = StringBuilder()
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null

    sb.append("<input type=\"radio\" ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))

        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "name"))
        "disabled" -> sb.append(getDisabledAttr(it))
        "value" -> {
          sb.append(getAttribute(it))
          sb.append("<c:if test=\"\${${getCheckedEl(attrs)}}\">checked=\"checked\"</c:if> ")
        }
        "name", "indexed", "idname" -> ""
        else -> sb.append(getAttribute(it))
      }
    }

    sb.append("/>")

    return sb.toString()
  }

  private fun getCheckedEl(attrs: Attributes): String {
    val sb = StringBuilder()
    val name = if (attrs.getValue("name").isNullOrEmpty()) formName else attrs.getValue("name")
    val exp = joinToString(name ?: "", attrs.getValue("property") ?: "")
    if (attrs.getValue("value").isEmpty()) {
      sb.append("empty $exp")
    } else {
      sb.append("$exp eq '${attrs.getValue("value")}'")
    }

    sb.append(" or ")
    sb.append("$exp eq 'on'")
    return sb.toString()
  }

  init {
    logId = "jp-017-01"
  }
}
