package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlMultiBoxTag(tag: Tag) : HtmlBaseTag(tag) {

  //    <form:checkboxes items="${webFrameworkList}" path="favoriteFrameworks" />
  override fun migration(): String {
    if (tag is EndTag) return "</form:checkbox>"

    val attrs = getAttrs()
    val sb = StringBuilder()
    sb.append("<form:checkbox ")
    attrs.forEach {

      when (it.key) {
        "property" -> sb.append(getAttribute("path", it.value))
        "value" -> sb.append(getAttribute("value", it.value))
        "disabled" -> sb.append(getDisabledAttr(it))
        else -> ""
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  init {
    logId = "jp-014-01"
  }

}
