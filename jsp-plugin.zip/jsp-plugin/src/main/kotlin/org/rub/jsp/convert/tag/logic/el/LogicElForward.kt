package org.rub.jsp.convert.tag.logic.el

class LogicElForward