package org.rub.jsp.convert.tag.bean



import net.htmlparser.jericho.Attributes
import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class BeanDefineTag(tag: Tag) : BaseTag(tag) {

  private val end = "</c:set>"

  // TODO
  override fun migration(): String {
    if (tag is EndTag) return end
    val sb = StringBuilder()
    val attrs = getAttrs()
    sb.append("<c:set ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "id" -> sb.append(getAttribute("var", it.value))
        "value" -> sb.append(getAttribute(it))
        "scope" -> if (it.value == "page") "" else sb.append(getAttribute(it))
        "property", "name", "type" -> ""
        else -> ""
      }
    }
    sb.append(getVarAttr(attrs))
    sb.append(appendEnd())
    return sb.toString()
  }

  private fun getVarAttr(attrs: Attributes): String {
    val value = StringBuilder()
    val name = attrs["name"]
    val property = attrs.getValue("property")
    val scope = attrs.getValue("scope")
    if (name == null) return ""
    value.append("\${")
    if (scope == "request" || scope == "session") {
      value.append(joinToString(scope + "Scope", name.value, property ?: ""))
    } else {
      value.append(joinToString(name.value, property ?: ""))
    }
    value.append("}")
    return getAttribute("value", value.toString())
  }

  init {
    logId = "jp-055-01"
  }

}
