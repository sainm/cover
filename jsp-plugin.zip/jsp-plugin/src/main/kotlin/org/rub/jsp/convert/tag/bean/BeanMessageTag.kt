package org.rub.jsp.convert.tag.bean



import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class BeanMessageTag(tag: Tag) : BaseTag(tag) {

  override fun migration(): String {
    val sb = StringBuilder()
    sb.append("<spring:message ")
    tag.parseAttributes().forEach {
      when (it.key.lowercase()) {
        "key" -> sb.append(getAttribute("code", it.value))
        "arg0" -> sb.append(getAttribute("arguments", it.value))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  init {
    logId = "jp-042-01"
  }
}
