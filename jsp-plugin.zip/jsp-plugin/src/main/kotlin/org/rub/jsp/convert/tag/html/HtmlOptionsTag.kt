package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlOptionsTag(tag: Tag) : HtmlBaseTag(tag) {

  override fun migration(): String {

    if (tag is EndTag) return "</form:options>"
    val attrs = getAttrs()

    val sb = StringBuilder()

    sb.append("<form:options ")

    val flg = attrs.getValue("property") == "id"

    attrs.forEach {
      when (it.key.lowercase()) {
        "collection" -> {
          sb.append(getAttribute("items", "\${${getCodeList(it.value, flg)}}"))
        }
        "labelproperty" -> if (it.value != "name") sb.append(getAttribute("itemLabel", it.value))
        "property" -> if (it.value != "id") sb.append(getAttribute("itemValue", it.value))
        "filter" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  private fun getCodeList(value: String, flg: Boolean): String {
    if (flg) return "CL_" + value.replace("-", "_")

    return value
  }

  init {
    logId = "jp-016-01"
  }
}
