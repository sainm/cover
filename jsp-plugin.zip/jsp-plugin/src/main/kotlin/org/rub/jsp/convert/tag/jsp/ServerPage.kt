//package org.rub.jsp.convert.tag.jsp
//
//
//
//import net.htmlparser.jericho.Tag
//import net.jhorstmann.jspparser.TreeParser
//import net.jhorstmann.jspparser.nodes.*
//import org.rub.jsp.BaseTag
//import org.rub.jsp.JspSetting
//import java.io.StringReader
//
//
//class ServerPage(tag: Tag) : BaseTag(tag) {
//  override fun migration(): String {
//    val p = TreeParser()
//
//    try {
//      p.parse(StringReader(tag.toString()))
//    } catch (e: Exception) {
//      throw Exception("before:\r\n======================================\r\n$tag")
//    }
//
//    val sb = StringBuilder()
//    when (p.rootNode.childNodes[0]) {
//      is PageDirectiveNode -> {
//        val page = p.firstChild as PageDirectiveNode
//        if (page.attributeMap["import"] == null)
//          return tag.toString()
//        else {
//          val str =page.attributeMap["import"]
//          if (str?.contains("jp.terasoluna.fw.web.struts.taglib.RandomUtil")!!) return ""
//          val replace = JspSetting.replace
//          sb.append("<%@ page ")
//          sb.append(
//            getAttribute(
//              "import",
//              replace.getProperty(page.attributeMap["import"]?.trim())
//                ?: page.attributeMap["import"].toString()
//            )
//          )
//          sb.append("%>")
//        }
//      }
//      is TaglibDirectiveNode -> {
//        log?.debug("tl-001-01")
//        log?.debug("tl-001-02")
//        log?.debug("tl-001-03")
//        log?.debug("tl-001-04")
//        log?.debug("tl-001-05")
//        log?.debug("tl-001-06")
//        log?.debug("tl-001-07")
//        log?.debug("tl-001-08")
//        log?.debug("tl-001-09")
//        log?.debug("tl-001-10")
//        log?.debug("tl-001-11")
//        log?.debug("tl-001-12")
//        log?.debug("tl-001-13")
//        log?.debug("tl-001-14")
//        log?.debug("tl-001-15")
//        log?.debug("tl-001-16")
//        log?.debug("tl-001-17")
//        log?.debug("tl-001-18")
//        log?.debug("tl-001-19")
//        log?.debug("tl-001-20")
//        log?.debug("tl-001-21")
//        log?.debug("tl-001-22")
//        log?.debug("tl-001-23")
//        log?.debug("tl-001-24")
//        log?.debug("tl-001-25")
//        log?.debug("tl-001-26")
//        log?.debug("tl-001-27")
//        log?.debug("tl-001-28")
//        log?.debug("tl-001-29")
//
//        when (getTagUri(p)) {
//          "/terasoluna-library",
//          "/struts-nested",
//          "/struts-html",
//          "/struts-bean",
//          "/struts-bean",
//          "/struts-logic",
//          "/terasoluna",
//          "/terasoluna-struts",
//          "/c",
//          "/fmt",
//          "/fn"
//          -> ""
//          else -> sb.append(tag.toString())
//        }
//      }
//      is TagDirectiveNode -> {
//        return tag.toString()
//      }
//      is ScriptletNode -> {
//        return tag.toString()
//      }
//      is ExpressionNode ->{
//        // <%= %>
//        val context = (p.rootNode.childNodes[0] as ScriptNode).content
//        if (context.trim()=="request.getContextPath()") return "\${pageContext.request.getContextPath()}"
//        if (context.contains(".")) return tag.toString()
//        return "\${${context.trim()}}"
//      }
//      is ScriptNode -> {
//        return tag.toString()
//      }
//
//      is IncludeDirectiveNode -> {
//        return tag.toString()
//      }
//
//    }
//
//    return sb.toString()
//  }
//
//  private fun getTagUri(p: TreeParser): String? {
//    val taglib = p.firstChild as TaglibDirectiveNode
//    return taglib.attributeMap["uri"]
//  }
//
//  fun getPageObj(p: TreeParser): Unit {
//
//  }
//
//  init {
//    logId = "jp-003-01"
//  }
//}
