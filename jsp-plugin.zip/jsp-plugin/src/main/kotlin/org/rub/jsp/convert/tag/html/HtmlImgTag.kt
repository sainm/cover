package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlImgTag(tag: Tag) : HtmlBaseTag(tag) {
  // <img src="<c:url value="${pageContext.request.contextPath}/resources/app/img/icon_jimu2.gif"/>"  border="0"/>

  override fun migration(): String {

    val sb = StringBuilder()
    sb.append("<img src=\"<c:url value=\"/resources/app/img/")
    val src = getAttrs().getValue("src").split("/").last()
    sb.append("$src\" />\" ")
    getAttrs().forEach {
      when (it.key.lowercase()) {
        "src" -> ""
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))
        else -> sb.append(getAttribute(it.key, it.value))
      }
    }
    sb.append(" />")
    return sb.toString()
  }

  init {
    logId = "jp-011-01"
  }

}
