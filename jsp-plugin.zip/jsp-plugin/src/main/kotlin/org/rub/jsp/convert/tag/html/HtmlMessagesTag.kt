package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlMessagesTag(tag: Tag) : HtmlBaseTag(tag) {

  override fun migration(): String {
    if (tag is EndTag) return "</r:message>"

    val sb = StringBuilder()
    sb.append("<r:message ")
    getAttrs().forEach {
      sb.append(getAttribute(it.key, it.value))
    }
    sb.append(">")
    return sb.toString()
  }

  init {
    logId = "jp-013-01"
  }

}
