package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlResetTag(tag: Tag) : HtmlBaseTag(tag) {
  init {
    logId = "jp-001-01"
  }
}
