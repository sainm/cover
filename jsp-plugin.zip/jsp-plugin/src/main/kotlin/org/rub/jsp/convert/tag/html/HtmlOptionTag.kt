package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlOptionTag(tag: Tag) : HtmlBaseTag(tag) {

  override fun migration(): String {
    if (tag is EndTag) return "</form:option>"
    val sb = StringBuilder()
    sb.append("<form:option ")

    val attrs = getAttrs()

    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("cssStyle", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())

    return sb.toString()
  }

  override fun migrationFormOuter(): String {
    if (tag is EndTag) return "</option>"
    val sb = StringBuilder()
    sb.append("<option ")

    val attrs = getAttrs()

    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))
        "disabled" -> sb.append(getDisabledAttr(it))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())

    return sb.toString()
  }

  init {
    logId = "jp-015-01"
  }
}
