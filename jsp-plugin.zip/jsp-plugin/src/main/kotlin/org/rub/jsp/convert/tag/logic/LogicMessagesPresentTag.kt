package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class LogicMessagesPresentTag(tag: Tag) : LogicBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return "</r:messagesPresent>"
    val sb = StringBuilder()
    sb.append("<r:messagesPresent ")
    getAttrs().forEach { sb.append(getAttribute(it.key, it.value)) }
    sb.append(appendEnd())
    return sb.toString()
  }

  init {
    logId = "jp-037-01"
  }
}
