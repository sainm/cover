package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlFormTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return "</form:form>"

    val sb = StringBuilder()
    val attrs = getAttrs()
    sb.append("<form:form ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "action" -> sb.append(getAttribute("servletRelativeAction", it.value.removeSuffix(".do")))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "style" -> sb.append(getAttribute("cssStyle", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        "disabled", "focus", "focusIndex", "readonly", "scriptLanguage" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append("modelAttribute=\"")
    sb.append(formName)
    sb.append("\" />")
    return sb.toString()
  }

  init {
    logId = "jp-008-01"
  }
}
