package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class LogicMatchTag(tag: Tag) : LogicBaseTag(tag) {

  override fun migration(): String {

    if (tag is EndTag) return "</c:if>"
    val sb = StringBuilder()
    val attrs = getAttrs()

    val location = attrs.getValue("location") ?: ""
    val value = attrs.getValue("value")
    val property = getPrefix(attrs.getValue("name")) + attrs.getValue("property")
    when (location) {
      "start" ->
        sb.append("<c:if test = \"\${fn:startsWith($property, '$value')}\"> ")
      "end" ->
        sb.append("<c:if test = \"\${fn:endsWith($property, '$value')}\"> ")
      else -> sb.append("<c:if test=\"\${fn:contains($property, '$value')}\">")
    }
    return sb.toString()
  }

  init {
    logId = "jp-031-01"
  }
}
