package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class LogicIterateTag(tag: Tag) : LogicBaseTag(tag) {

  override fun migration(): String {

    val attributeMap = mutableMapOf<String, String>()
    if (tag is EndTag) return "</c:forEach>"

    val attrs = getAttrs()
    val sb = StringBuilder()
    val offset = if (attrs.get("offset") == null) "" else attrs.getValue("offset").replace("<%", "").replace("=", "")
      .replace("%>", "")
    sb.append("<c:forEach ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "offset" -> attributeMap["begin"] = getAttribute(
          "begin",
          "\${${it.value.replace("<%", "").replace("=", "").replace("%>", "").trim()}}"
        )
        "length" -> {
          attributeMap["end"] = getAttribute(
            "end",
            "\${${offsetCheck(offset)}" + it.value.replace("\${", "").replace("}", "").replace("<%", "")
              .replace("=", "").replace("%>", "")
              .trim() + " - 1}"
          )
        }
        "id" -> attributeMap["var"] = getAttribute("var", it.value)
        "indexid" -> attributeMap["varStatus"] = getAttribute("varStatus", it.value)
        "property", "name" -> ""
        else -> ""
      }
    }

    val property = attrs.getValue("property")
    val name = attrs.getValue("name")
    attributeMap["items"] = getAttribute("items", getItems(name, property))

    if (attributeMap["var"] != null) sb.append(attributeMap["var"])
    if (attributeMap["varStatus"] != null) sb.append(attributeMap["varStatus"])
    if (attributeMap["items"] != null) sb.append(attributeMap["items"])
    if (attributeMap["begin"] != null) sb.append(attributeMap["begin"])
    if (attributeMap["end"] != null) sb.append(attributeMap["end"])

    if (attrs.get("indexid").isNullOrEmpty()) sb.append(getAttribute("varStatus", "loopStatus"))
    sb.append(appendEnd())
    return sb.toString()
  }

  private fun offsetCheck(offset: String): String {

    val editStr: String = when (offset) {
      "" -> offset
      "0" -> ""
      else -> "$offset + "
    }
    return editStr
  }

  private fun getItems(name: String?, property: String?): String {
    return if (name.isNullOrEmpty()) "\${${property}}"
    else {
      if (property.isNullOrEmpty()) "\${${name}}"
      else "\${${name}.${property}}"
    }
  }

  init {
    logId = "jp-028-01"
  }
}
