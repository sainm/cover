package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlLinkTag(tag: Tag) : HtmlBaseTag(tag) {


//    <a href=�f<c:url �`>�f></a>

  override fun migration(): String {


    if (tag is EndTag) return "</a>"
    val attrs = getAttrs()
    val sb = StringBuilder()
    sb.append("<a ")


    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> ""
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        else -> sb.append(getAttribute(it))
      }
    }

    sb.append(appendEnd())

    return sb.toString()
  }

  init {
    logId = "jp-012-01"
  }
}
