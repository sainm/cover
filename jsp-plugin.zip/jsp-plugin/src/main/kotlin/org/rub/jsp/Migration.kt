package org.rub.jsp



import net.htmlparser.jericho.Source
import net.htmlparser.jericho.StartTag
import net.htmlparser.jericho.Tag
import org.slf4j.Logger
import java.io.Reader
import java.nio.file.Files
import java.nio.file.Path

class Migration(setting: JspSetting) {

  private val setting: JspSetting

  private var context = ""

  private val logger: Logger

  init {
    this.setting = setting
    this.logger = setting.logger
  }

  fun migrate(reader: Reader): String {

    val source = Source(reader)
    val src = StringBuffer(source.toString())
    val tags = source.getAllTags()
    val bool = tags.any { it.name.endsWith("form") && it is StartTag }
    val form = if (bool) tags.first { it.name.endsWith("form") && it is StartTag } else null
    val formName = getFormName(form, setting)
    val builder = StringBuilder()
    var position = 0
    BaseTag.setting = setting
    val util = TagUtil(setting)
    tags.forEach {
      if (it.begin >= position) {
        val tag = util.getTag(it)

        builder.append(src.substring(position, it.begin))

        tag.log = logger
        tag.formName = formName
        val flg: Boolean = getFormIn(it, form)
        tag.formFlg = flg
        position = it.end
        builder.append(tag.execute())
        logger.debug(tag.logId)
      }
    }
    builder.append(src.substring(position))
    var ret = builder.toString()
    val regex = Regex("<bean:message[\\s*\\S*]*?/>")
    ret = executeInLine(builder.toString(), util, regex, formName)
    val regex2 = Regex("<html:rewrite[\\s*\\S*]*?/>")
    ret = executeInLine(ret, util, regex2, formName)

    val regex3 = Regex("<bean:write[\\s*\\S*]*?/>")
    ret = executeInLine(ret, util, regex3, formName)

    val regex4 = Regex("<t:write[\\s*\\S*]*?/>")
    ret = executeInLine(ret, util, regex4, formName)

    context = ret.replace(".do?", "?")
      .replace(".do\"", "\"")
      .replace(".do'", "'")

      // TODO
      .replace("'org.apache.struts.action.ERROR'", "'ERROR_KEY'")
      .replace("'org.apache.struts.action.ACTION_MESSAGE'", "'MESSAGE_KEY'")
      .replace("jp.terasoluna.fw.web.struts.taglib.RandomUtil.", "jp.go.mhlw.lsys.web.taglib.RandomUtil.")
      .replace("jp.terasoluna.fw.util.PropertyUtil.", "jp.go.mhlw.lsys.common.util.PropertyUtil.")

//    try {
//      context = context.replace("<%=\\s*[a-zA-Z0-9_]+\\s*%>".toRegex(), "\\\${$1}")
//    } catch (e: Exception) {
//      logger.error("", e)
//    }
    return context

  }

  private fun getFormName(form: Tag?, setting: JspSetting): String {
    if (form == null) return ""

    val action =
      adjustActionPath(form.parseAttributes().getValue("action")?.removeSuffix(".do"), setting.fileAbsPath)
        ?: return ""
    val map = setting.actionMap
    return map[action.fullPath] ?: ""
  }

  fun save(path: Path) {
    Files.writeString(path, context, setting.charset)
  }

  private fun getFormIn(tag: Tag, form: Tag?): Boolean {
    if (form == null) return false
    val begin = form.getElement().getBegin()
    val end = form.getElement().getEnd()
    if (tag.begin > begin && begin < end) return true

    return false
  }

  private fun executeInLine(context: String, util: TagUtil, regex: Regex, form: String): String {
    var content = context
    val rets = regex.findAll(context)
    rets.forEach {
      val s = Source(it.value)
      val tag = util.getTag(s.getAllTags()[0])
      tag.formName = form
      val text = tag.migration()
      content = content.replace(s.toString(), text)

      logger.debug(tag.logId)
    }
    return content
  }
}
