package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlOptionsCollectionTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return "</form:options>"
    val attrs = getAttrs()
    val sb = StringBuilder()
    sb.append("<form:options ")
    attrs.forEach {
      when (it.key) {
        "property" -> sb.append(getAttribute("items", "\${" + getPrefix(attrs.getValue("name")) + it.value + "}"))
        "value" -> sb.append(getAttribute("itemValue", it.value))
        "label" -> sb.append(getAttribute("itemLabel", it.value))
      }
    }
    sb.append(appendEnd())
    return sb.toString()
  }

  init {
    logId = "jp-020-01"
  }

}
