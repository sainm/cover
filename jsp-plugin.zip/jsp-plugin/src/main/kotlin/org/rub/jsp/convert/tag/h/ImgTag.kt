package org.rub.jsp.convert.tag.h


import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class ImgTag(tag: Tag) : BaseTag(tag) {

  init {
    logId = "jp-011-01"
  }

  override fun migration(): String {
    val sb = StringBuilder()
    sb.append("<img src=\"<c:url value=\"/resources/app/img/")
    try {
      val src = getAttrs().getValue("src").split("/").last()
      sb.append("$src\" />\" ")
      getAttrs().forEach {
        when (it.key) {
          "src" -> ""
          "style" -> sb.append(getAttribute("style", it.value))
          "styleid" -> sb.append(getAttribute("id", it.value))
          "styleclass" -> sb.append(getAttribute("class", it.value))
          else -> sb.append(getAttribute(it.key, it.value))
        }
      }
    } catch (e: Exception) {
      throw Exception("before:\r\n======================================\r\n$tag")
    }
    sb.append(appendEnd())
    return sb.toString()
  }
}
