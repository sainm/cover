package org.rub.jsp

import org.slf4j.Logger
import java.io.IOException
import java.nio.charset.Charset
import java.util.*

class JspSetting(val logger: Logger) {

  var form = ""

  var fileAbsPath: String = ""

  // TODO
  var charset: Charset = charset("shift-jis")

  var actionMap = mutableMapOf<String, String?>()

  val properties = Tag.properties

  val replace = Tag.replace

  companion object Tag {
    val properties: Properties = Properties()

    val replace: Properties = Properties()

    init {
      try {
        val stream = this::class.java.getResourceAsStream("/reflectDic.properties")
        properties.load(stream)
        val rep = this::class.java.getResourceAsStream("/replace.properties")
        replace.load(rep)
      } catch (e: IOException) {
        e.printStackTrace()
      }
    }
  }


}
