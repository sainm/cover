package org.rub.jsp.convert.tag.bean


import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class BeanWriteTag(tag: Tag) : BaseTag(tag) {

  override fun migration(): String {
    val attrs = getAttrs()
    val sb = StringBuilder()
    val format = attrs.getValue("format")
    val scope = attrs.getValue("scope")
    val name = attrs.getValue("name")
    val property = attrs.getValue("property")
    if (format.isNullOrEmpty()) {
      if (tag is EndTag) return ""
      if (attrs.getValue("filter") == null || attrs.getValue("filter").toBoolean()) {
        sb.append("\${")
        sb.append(getContext(scope, name, property))
        sb.append("}")
      } else {
        sb.append("<c:out ")
        attrs.forEach {
          when (it.key) {
            "filter" -> sb.append(getAttribute("escapeXml", it.value))
            "name" -> {
              sb.append("value=\"\${")
              sb.append(getContext(scope, name, property))
              sb.append("}\" ")
            }
            "ignore" -> {
              if (it.value.toBoolean()) sb.append(getAttribute("default", ""))
            }
            "property", "scope" -> ""
            else -> ""
          }
        }
        sb.append("/>")
      }
    } else {
      if (format.contains("#")) {
        if (tag is EndTag) return "</fmt:formatNumber>"
        sb.append("<fmt:formatNumber ")
        attrs.forEach {
          when (it.key) {
            "name" -> {
              sb.append("value=\"\${")
              sb.append(getContext(scope, name, property))
              sb.append("}\" ")
            }
            "format" -> sb.append(getAttribute("pattern", it.value))
            "property", "scope" -> ""
            else -> ""
          }
        }
      } else {
        if (tag is EndTag) return "</fmt:formatDate>"
        sb.append("<fmt:formatDate ")
        attrs.forEach {
          when (it.key) {
            "name" -> {
              sb.append("value=\"\${")
              sb.append(getContext(scope, name, property))
              sb.append("}\" ")
            }
            "format" -> sb.append(getAttribute("pattern", it.value))
            "property", "scope" -> ""
            else -> ""
          }
        }
      }
      sb.append("/>")
    }

    return sb.toString()
  }

  private fun getContext(scope: String?, name: String?, property: String?): String {
    return if (scope == "request" || scope == "session") {
      joinToString(scope + "Scope", name ?: "", property ?: "")
    } else {
      joinToString(name ?: "", property ?: "")
    }
  }

  init {
    logId = "jp-041-01"
  }

}
