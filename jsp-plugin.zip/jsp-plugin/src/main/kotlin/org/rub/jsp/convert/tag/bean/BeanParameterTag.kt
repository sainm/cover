package org.rub.jsp.convert.tag.bean


import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class BeanParameterTag(tag: Tag) : BaseTag(tag) {
}
