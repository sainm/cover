package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlPasswordTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return ""

    val attrs = getAttrs()


    val sb = StringBuilder()
    sb.append("<form:password ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "property" -> sb.append(getAttribute("path", it.value))
        else -> sb.append(getAttribute(it.key, it.value))
      }
    }

    sb.append("/>")

    return sb.toString()
  }

  init {
    logId = "jp-001-01"
  }
}
