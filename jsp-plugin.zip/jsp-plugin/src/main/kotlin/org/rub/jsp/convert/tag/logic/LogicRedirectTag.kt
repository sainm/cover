package org.rub.jsp.convert.tag.logic

import net.htmlparser.jericho.Tag


class LogicRedirectTag(tag: Tag) : LogicBaseTag(tag) {
  override fun migration(): String {

    val sb = StringBuilder()
    val attrs = getAttrs()
    val forward = attrs.getValue("forward")
    sb.append("<c:redirect")
    sb.append(getAttribute("url", "<c:url value=\"$forward"))
    sb.append(appendEnd())
    return sb.toString()
  }

  init {
    logId = "jp-001-01"
  }
}
