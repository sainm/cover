package org.rub.jsp.convert.tag.bean


import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

class BeanSizeTag(tag: Tag) : BaseTag(tag) {

  //    <c:set value=�h${fn:length(�`)}�h />
  override fun migration(): String {

    val attrs = getAttrs()

    val sb = StringBuilder()
    sb.append("<c:set ")

    attrs.forEach {
      when (it.key.lowercase()) {
        "id" -> sb.append(getAttribute("var", attrs.getValue("id")))
        "name" -> sb.append(
          getAttribute(
            "value",
            getFn(joinToString(attrs.getValue("name") ?: "", attrs.getValue("property") ?: ""))
          )
        )
        "scope" -> if (it.value == "page") "" else sb.append(getAttribute(it))
        "property" -> ""
        else -> ""
      }
    }

    sb.append("/>")
    return sb.toString()
  }

  private fun getFn(property: String): String {
    return "\${fn:length($property)}"
  }

  init {
    logId = "jp-040-01"
  }

}
