package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlButtonTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {

    val sb = StringBuilder()
    sb.append("<input type=\"button\" ")
    val attrs = getAttrs()
    attrs.forEach {
      when (it.key.lowercase()) {
        "styleid" -> sb.append(getAttribute("id", it.value))
        "property" -> sb.append(getAttribute("name", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))
        "disabled" -> sb.append(getDisabledAttr(it))
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append("/>")
    return sb.toString()
  }

  init {
    logId = "jp-004-01"
  }
}
