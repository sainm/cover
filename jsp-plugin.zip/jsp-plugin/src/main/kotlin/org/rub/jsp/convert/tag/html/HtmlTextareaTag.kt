package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlTextareaTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return "</form:textarea>"
    val sb = StringBuilder()

    val attrs = getAttrs()
    sb.append("<form:textarea ")
    val indexed: Boolean = attrs.getValue("indexed") != null
    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("cssStyle", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "path"))
        "readonly" -> sb.append(getAttribute(it.key, it.value))
        "indexed", "name" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(appendEnd())

    return sb.toString()
  }

  init {
    logId = "jp-023-01"
  }
}
