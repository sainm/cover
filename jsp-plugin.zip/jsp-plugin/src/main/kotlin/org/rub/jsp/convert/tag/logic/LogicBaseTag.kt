package org.rub.jsp.convert.tag.logic


import net.htmlparser.jericho.Tag
import org.rub.jsp.BaseTag

open class LogicBaseTag(tag: Tag) : BaseTag(tag) {

  open fun getContext(name: String?, property: String?): String? {
    return joinToString(name ?: "", property ?: "")
  }
}
