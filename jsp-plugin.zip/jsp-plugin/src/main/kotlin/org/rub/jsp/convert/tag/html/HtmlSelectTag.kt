package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlSelectTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {

    if (tag is EndTag) return "</form:select>"
    val sb = StringBuilder()
    sb.append("<form:select ")
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null
    attrs.forEach {
      when (it.key.lowercase()) {
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "path"))
        "style" -> sb.append(getAttribute("cssStyle", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))
        "multiple" -> {
          if (it.value == "multiple")
            sb.append(getAttribute("multiple", "true"))
          else
            sb.append(getAttribute(it))
        }
        "indexed", "name" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append(">")
    return sb.toString()
  }

  override fun migrationFormOuter(): String {
    return migration()
    // TODO
//    if (tag is EndTag) return "</select>"
//    val sb = StringBuilder()
//    sb.append("<select ")
//    val attrs = getAttrs()
//    val indexed: Boolean = attrs.getValue("indexed") != null
//    attrs.forEach {
//      when (it.key.lowercase()) {
//        "style" -> sb.append(getAttribute("style", it.value))
//        "styleid" -> sb.append(getAttribute("id", it.value))
//        "styleclass" -> sb.append(getAttribute("class", it.value))
//
//        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "name"))
//        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))
//        "disabled" -> sb.append(getDisabledAttr(it))
//
//        "multiple" -> {
//          if (it.value == "multiple")
//            sb.append(getAttribute("multiple", "true"))
//          else
//            sb.append(getAttribute(it))
//        }
//        "indexed", "name" -> ""
//        else -> sb.append(getAttribute(it))
//      }
//    }
//    sb.append(">")
//    return sb.toString()
  }

  init {
    logId = "jp-019-01"
  }
}
