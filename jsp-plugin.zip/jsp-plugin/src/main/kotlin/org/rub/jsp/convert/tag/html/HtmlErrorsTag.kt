package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlErrorsTag(tag: Tag) : HtmlBaseTag(tag) {

  override fun migration(): String {
    return tag.toString().replace("html", "r")
  }

  init {
    logId = "jp-006-01"
  }
}
