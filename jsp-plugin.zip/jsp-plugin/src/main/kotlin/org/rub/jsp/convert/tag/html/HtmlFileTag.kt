package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlFileTag(tag: Tag) : HtmlBaseTag(tag) {

  override fun migration(): String {
    val sb = StringBuilder()
    sb.append("<input type = \"file\" ")
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null
    attrs.forEach {
      when (it.key.lowercase()) {
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))
        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))
        "onkeydown" -> sb.append(getAttribute(it.key, it.value))
        "indexed", "name" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    sb.append("/>")
    return sb.toString()
  }

  init {
    logId = "jp-007-01"
  }

}
