package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.Tag


class HtmlFrameTag(tag: Tag) : HtmlBaseTag(tag) {
  init {
    logId = "jp-001-01"
  }
}
