package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlCheckboxTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {

    if (tag is EndTag) return ""
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null
    val sb = StringBuilder()
    sb.append("<form:checkbox ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "path"))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "style" -> sb.append(getAttribute("cssStyle", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        "disabled" -> sb.append(getAttribute("disabled", "true"))
        "value" -> sb.append(getAttribute(it))
        "indexed", "name" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    if (attrs.get("value") == null) sb.append(getAttribute("value", "on"))
    sb.append("/>")
    return sb.toString()
  }

  override fun migrationFormOuter(): String {

    if (tag is EndTag) return ""
    val attrs = getAttrs()
    val indexed: Boolean = attrs.getValue("indexed") != null
    val sb = StringBuilder()
    sb.append("<input type=\"checkbox\" ")
    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "name"))
        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))
        "alt" -> {
          if (!attrs.get("altkey").isNullOrEmpty()) sb.append(
            getAttribute(
              "alt",
              "<spring:message code=\"${attrs.get("altkey").value}\"/>"
            )
          )
          else sb.append(getAttribute(it))

        }
        "title" -> {
          if (!attrs.get("titlekey").isNullOrEmpty()) sb.append(
            getAttribute(
              "title",
              "<spring:message code=\"${attrs.get("titlekey").value}\"/>"
            )
          )
          else sb.append(getAttribute(it))
        }
        "disabled" -> sb.append(getDisabledAttr(it))
        "value" -> sb.append("<c:if test=\"\${${attrs.getValue("property")} eq '${it.value}'}\">checked=\"checked\"</c:if> ")
        "altkey", "bundle", "indexed", "name", "titlekey" -> ""
        else -> sb.append(getAttribute(it))
      }
    }
    // TODO ?
    if (attrs.get("value") == null) sb.append(getAttribute("value", "on"))
    sb.append("/>")
    return sb.toString()
  }

  init {
    logId = "jp-005-01"
  }
}
