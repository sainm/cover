package org.rub.jsp

import net.htmlparser.jericho.Attribute
import net.htmlparser.jericho.Attributes
import net.htmlparser.jericho.Tag

import org.slf4j.Logger

open class BaseTag(val tag: Tag) {

  var log: Logger? = null

  var logId = "jp-000-01"

  var formFlg: Boolean = false

  var formName: String = ""

  open fun migration(): String {
    return tag.toString()
  }

  open fun execute(): String {
    return migration()
  }

  open fun append(): String {
    return tag.getElement().content.toString()
  }

  fun getAttribute(key: String, value: String): String {
    return "$key=\"$value\" "
  }

  fun getAttribute(attribute: Attribute): String {
    return "${attribute.key}=\"${attribute.value}\" "
  }

  fun getAttrs(): Attributes {
    return tag.parseAttributes()
  }

  open fun getPrefix(name: String): String {
    if (name.isEmpty()) return ""
    if (formName == name) return ""

    return "$name."
  }

  fun appendEnd(): String {
    return if (tag.toString().endsWith("/>"))
      "/>"
    else
      ">"
  }

  open fun innerConvert(): String {
    return tag.getElement().content.toString()
  }

  open fun getDisabledAttr(attr: Attribute): String {
    return when (attr.value.lowercase()) {
      "true" -> getAttribute("disabled", "disabled")
      "false" -> ""
      else -> "<c:if test=\"${attr.value}\">disabled=\"disabled\"</c:if> "
    }
  }

  open fun joinToString(vararg strs: String): String {
    return strs.filter { it.isNotEmpty() }.joinToString(separator = ".")
  }

  companion object {
    var setting: JspSetting? = null
  }
}
