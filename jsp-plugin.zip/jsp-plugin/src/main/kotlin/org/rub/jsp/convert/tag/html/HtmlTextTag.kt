package org.rub.jsp.convert.tag.html

import net.htmlparser.jericho.EndTag
import net.htmlparser.jericho.Tag


class HtmlTextTag(tag: Tag) : HtmlBaseTag(tag) {
  override fun migration(): String {
    if (tag is EndTag) return ""

    val attrs = getAttrs()
    if (attrs.get("value") != null) return migrationFormOuter()

    val sb = StringBuilder()
    sb.append("<form:input ")
    val indexed: Boolean = attrs.getValue("indexed") != null
    attrs.forEach {
      when (it.key.lowercase()) {
        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "path"))
        "style" -> sb.append(getAttribute("cssStyle", it.value))
        "styleclass" -> sb.append(getAttribute("cssClass", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))
        "name", "indexed" -> ""
        else -> sb.append(getAttribute(it.key, it.value))
      }
    }

    sb.append("/>")

    return sb.toString()
  }

  override fun migrationFormOuter(): String {
    if (tag is EndTag) return ""
    val sb = StringBuilder()
    val attrs = getAttrs()
    val value = attrs.get("value") == null
    sb.append("<input type=\"text\" ")
    val indexed: Boolean = attrs.getValue("indexed") != null
    attrs.forEach {
      when (it.key.lowercase()) {
        "style" -> sb.append(getAttribute("style", it.value))
        "styleid" -> sb.append(getAttribute("id", it.value))
        "styleclass" -> sb.append(getAttribute("class", it.value))

        "property" -> sb.append(getIndexForAttr(indexed, it, attrs, "name"))
        "disabled" -> sb.append(getDisabledAttr(it))
        "errorstyleclass" -> sb.append(getAttribute("cssErrorClass", it.value))

        "value" -> sb.append(getAttribute(it))
        "name", "indexed" -> ""
        else -> sb.append(getAttribute(it))
      }
    }

    if (value && !attrs.getValue("name").isNullOrEmpty()) sb.append(getAttribute("value", getElForNameProperty(attrs)))
    sb.append("/>")

    return sb.toString()
  }

  init {
    logId = "jp-022-01"
  }
}
